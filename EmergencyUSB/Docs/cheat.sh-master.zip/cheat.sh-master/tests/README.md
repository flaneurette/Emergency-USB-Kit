To run unit tests.

    python3 -m pytest -v ../lib/

To run input/output tests.

    ./run-tests.sh
