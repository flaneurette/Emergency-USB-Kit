# adb start-server

> Start the Android Debug Bridge (adb) server to allow adb connections from devices or emulators.
> More information: <https://manned.org/adb#head14>.

- Start the adb server if it is not running:

`adb start-server`
