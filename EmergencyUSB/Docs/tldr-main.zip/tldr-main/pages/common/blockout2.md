# blockout2

> Tetris like game in 3D.
> More information: <https://www.blockout.net/blockout2/>.

- Start a new game:

`blockout2`

- Navigate the current piece on a 2D plane:

`{{<ArrowUp>|<ArrowDown>|<ArrowLeft>|<ArrowRight>}}`

- Rotate the piece on its axis:

`{{<q>|<w>|<e>|<a>|<s>|<d>}}`

- Hard drop the current piece:

`<Space>`

- Pause/unpause the game:

`<p>`
