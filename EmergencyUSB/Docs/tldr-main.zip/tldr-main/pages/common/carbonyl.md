# carbonyl

> View webpages on the terminal using a Chromium backend.
> See also: `browsh`.
> More information: <https://github.com/fathyb/carbonyl>.

- Open an `about:blank` page:

`carbonyl`

- Open a webpage:

`carbonyl {{https://example.com}}`

- Exit carbonyl:

`<Ctrl c>`

- Display help:

`carbonyl {{[-h|--help]}}`
