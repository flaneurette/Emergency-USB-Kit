# bun rm

> This command is an alias of `bun remove`.

- View documentation for the original command:

`tldr bun remove`
