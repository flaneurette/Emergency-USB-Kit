# arch

> This command is an alias of `uname --machine`.

- View documentation for the original command:

`tldr uname`
