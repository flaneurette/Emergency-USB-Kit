# bzip2recover

> Attempt to recover data from a damaged `.bz2` file.
> See also: `bzip2`.
> More information: <https://manned.org/bzip2recover>.

- Recover all intact blocks from a damaged `.bz2` file:

`bzip2recover {{damaged_file.bz2}}`
