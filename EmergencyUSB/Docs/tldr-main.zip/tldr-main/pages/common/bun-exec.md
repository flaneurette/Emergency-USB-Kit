# bun exec

> Execute shell commands or script files using Bun's runtime.
> Note: When running from a shell, remember to escape quotes.
> More information: <https://bun.com/docs/runtime/shell>.

- Run a simple command:

`bun exec "echo hello"`

- Run a command with flags:

`bun exec "ls -la"`

- Run a command containing quotes:

`bun exec "echo \"hello friends\""`

- Run a combined shell command:

`bun exec "mkdir test && cd test"`

- Run a script file:

`bun exec {{path/to/script}}`
