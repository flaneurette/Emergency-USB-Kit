# bzfgrep

> This command is an alias of `bzgrep --fixed-strings`.

- View documentation for the original command:

`tldr bzgrep`
