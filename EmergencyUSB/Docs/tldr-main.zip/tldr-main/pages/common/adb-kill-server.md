# adb kill-server

> Stop the Android Debug Bridge (adb) server, disconnecting devices and emulators.
> More information: <https://manned.org/adb#head14>.

- Kill the adb server if it is running:

`adb kill-server`
