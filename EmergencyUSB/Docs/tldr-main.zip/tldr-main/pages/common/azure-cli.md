# azure-cli

> This command is an alias of `az`.

- View documentation for the original command:

`tldr az`
