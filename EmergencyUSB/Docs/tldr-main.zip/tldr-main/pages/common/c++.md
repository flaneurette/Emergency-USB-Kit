# c++

> This command is an alias of `g++`.

- View documentation for the original command:

`tldr g++`
