# bun x

> This command is an alias of `bunx`.

- View documentation for the original command:

`tldr bunx`
