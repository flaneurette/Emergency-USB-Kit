# bzegrep

> This command is an alias of `bzgrep --extended-regexp`.

- View documentation for the original command:

`tldr bzgrep`
