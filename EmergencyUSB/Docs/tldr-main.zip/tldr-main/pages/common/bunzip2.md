# bunzip2

> This command is an alias of `bzip2 --decompress`.

- View documentation for the original command:

`tldr bzip2`
