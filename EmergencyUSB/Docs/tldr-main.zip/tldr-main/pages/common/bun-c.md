# bun c

> This command is an alias of `bun create`.

- View documentation for the original command:

`tldr bun create`
