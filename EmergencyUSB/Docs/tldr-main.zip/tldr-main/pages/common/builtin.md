# builtin

> Execute shell builtins.
> More information: <https://www.gnu.org/software/bash/manual/bash.html#index-builtin>.

- Run a shell builtin:

`builtin {{command}}`
