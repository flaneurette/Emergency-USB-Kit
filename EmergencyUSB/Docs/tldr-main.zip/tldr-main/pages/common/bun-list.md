# bun list

> This command is an alias of `bun pm ls`.

- View documentation for the original command:

`tldr bun pm ls`
