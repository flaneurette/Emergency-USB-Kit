# bun pm migrate

> Convert another package manager's lockfile to a Bun-compatible lockfile without installing anything.
> More information: <https://bun.com/docs/pm/cli/pm#migrate>.

- Migrate the lockfile in the current project:

`bun pm migrate`
