# bun i

> This command is an alias of `bun install`.

- View documentation for the original command:

`tldr bun install`
