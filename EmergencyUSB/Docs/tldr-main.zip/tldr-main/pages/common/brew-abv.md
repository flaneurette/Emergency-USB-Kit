# brew abv

> This command is an alias of `brew info`.

- View documentation for the original command:

`tldr brew info`
