# bmptoppm

> This command has been superseded by `bmptopnm`.
> More information: <https://netpbm.sourceforge.net/doc/bmptoppm.html>.

- View documentation for the current command:

`tldr bmptopnm`
