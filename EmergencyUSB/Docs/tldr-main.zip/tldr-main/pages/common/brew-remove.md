# brew remove

> This command is an alias of `brew uninstall`.

- View documentation for the original command:

`tldr brew uninstall`
