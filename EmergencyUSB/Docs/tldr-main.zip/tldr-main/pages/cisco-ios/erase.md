# erase

> Delete preset things.
> More information: <https://www.cisco.com/c/en/us/td/docs/ios/ios_xe/fundamentals/configuration/guide/2_xe/cf_xe_book/cf_config-files_xe.html>.

- Erase the startup configuration:

`erase startup-config`

- Erase a filesystem:

`erase {{flash}}:`
