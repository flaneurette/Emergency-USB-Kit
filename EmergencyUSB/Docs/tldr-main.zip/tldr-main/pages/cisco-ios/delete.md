# delete

> Delete individual files.
> More information: <https://www.cisco.com/c/en/us/td/docs/switches/datacenter/nexus5000/sw/command/reference/fund/n5k-fund-cr/n5k-fund_cmds_d.html#delete>.

- Delete a file from flash memory:

`delete {{vlan.dat}}`
