# login

> Manage console and virtual line authentication.
> Accessed in configuration mode under `line`.
> More information: <https://www.cisco.com/c/en/us/td/docs/routers/sdwan/command/iosxe/qualified-cli-command-reference-guide/m-line-commands.pdf>.

- Use local username and password for authentication:

`login local`
