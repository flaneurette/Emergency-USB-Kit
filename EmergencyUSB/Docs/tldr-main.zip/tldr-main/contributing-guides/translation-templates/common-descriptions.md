# Common descriptions

This page provides translations of commonly used descriptions to simplify maintaining pages in foreign languages.\
The best way to edit this file is by using [tableconvert.com](https://tableconvert.com/markdown-to-markdown).\
There, the old table can be **imported**, **edited** in a WYSIWYG editor and **exported** again.\
Only the left-alignment of the header gets lost and has to be re-added again (`|----` → `|:---`).

| en    | Display help       | Display version       | [Interactive]    |
|-------|--------------------|-----------------------|------------------|
| ar    | عرض المساعدة       | عرض الإصدار           | [تفاعلية]        |
| bn    | সাহায্য প্রদর্শন   | ভার্সন দেখুন          | [ইন্টার‌্যাকটিভ] |
| bs    |                    |                       |                  |
| ca    | Mostra ajuda       | Mostra la versió      |                  |
| cs    | Zobrazit nápovědu  | Zobrazit verzi        | [Interaktivní]   |
| da    | Vis hjælp          | Vis version           |                  |
| de    | Zeige Hilfe an     | Zeige Version an      |                  |
| el    | Εμφάνιση Βοήθειας  | Εμφάνιση Έκδοσης      |                  |
| es    | Muestra la ayuda   | Muestra la versión    | [Interactivo]    |
| fa    | نمایش راهنما       |                       |                  |
| fi    | Näytä ohje         | Näytä versio          | [Interaktiotila] |
| fr    | Affiche l'aide     | Affiche la version    | [Interactif]     |
| hi    | मदद प्रदर्शित करें | संस्करण दिखाएं        |                  |
| id    | Tampilkan bantuan  |                       |                  |
| it    | Mostra l'aiuto     | Controlla la versione | [Interattivo]    |
| ja    | ヘルプを表示する           | バージョンを表示              |                  |
| ko    | 도움말 표시             | 버전 표시                 |                  |
| lo    |                    |                       |                  |
| ml    |                    |                       |                  |
| ne    |                    |                       |                  |
| nl    | Toon de help       | Toon de versie        | [Interactief]    |
| no    |                    |                       |                  |
| pl    | Wyświetl pomoc     | Wyświetl wersję       | [Interaktywne]   |
| pt_BR | Mostra ajuda       | Mostra versão         |                  |
| pt_PT |                    |                       |                  |
| ro    | Afișare ajutor     | Afișare versiune      | [Interactiv]     |
| ru    | Показать справку   | Показать версию       | [Интерактивно]   |
| sr    |                    |                       |                  |
| sv    |                    |                       |                  |
| ta    | உதவியைக் காட்டு    | பதிப்பைக் காட்டு      | [ஊடாடும் கட்டளை] |
| th    | แสดงวิธีใช้งาน     | แสดงเวอร์ชัน          | [อินเทอร์แอคทีฟ] |
| tr    | Yardımı görüntüle  | Sürümü görüntüle      | [Etkileşimli]    |
| uk    |                    |                       |                  |
| uz    |                    |                       |                  |
| zh    | 显示说明               | 显示版本                  | [交互式]            |
| zh_TW | 顯示說明               | 顯示版本                  | [互動式]            |

